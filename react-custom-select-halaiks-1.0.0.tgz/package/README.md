# react-custom-select-halaiks

Custom React Select component with keyboard navigation and search support.

## Installation

```bash
npm install react-custom-select-halaiks
```

## Usage

```jsx
import { useState } from "react"
import Select from "react-custom-select-halaiks"
import "react-custom-select-halaiks/style.css"

function App() {
  const [selectedOption, setSelectedOption] = useState(null)

  const options = [
    { value: "marketing", label: "Marketing" },
    { value: "sales", label: "Sales" },
    { value: "engineering", label: "Engineering" }
  ]

  return (
    <Select
      label="Department"
      options={options}
      value={selectedOption}
      onChange={setSelectedOption}
      placeholder="Select a department"
    />
  )
}

export default App
```

## Props

| Prop | Type | Description |
|------|------|------|
| label | string | Field label |
| options | array | List of options |
| value | object | Selected option |
| onChange | function | Callback on selection |
| placeholder | string | Placeholder text |

## Features

- Keyboard navigation
- Accessible dropdown
- Search support
- Custom styling
- React 18 and 19 compatible
- Vite compatible

## License

MIT